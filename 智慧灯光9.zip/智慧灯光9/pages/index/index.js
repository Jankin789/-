// index.js
const defaultAvatarUrl = 'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0'

Page({
  data: {
    currentMode: 'reading',
    brightness: 50,
    colorTemp: 50,
    saturation: 50,
    hue: 0,
    readingScenes: [
      { 
        name: '护眼模式', 
        value: 'eyecare', 
        color: '#CCE8CF',
        icon: '👀',
        description: '呵护眼睛',
        brightness: 60,
        colorTemp: 40,
        saturation: 30,
        hue: 120 
      },
      { 
        name: '纸张模式', 
        value: 'paper', 
        color: '#FFF5E1',
        icon: '📖',
        description: '仿真纸张',
        brightness: 75,
        colorTemp: 65,
        saturation: 20,
        hue: 30 
      },
      { 
        name: '夜间模式', 
        value: 'night', 
        color: '#FFE4B5',
        icon: '🌙',
        description: '柔和护眼',
        brightness: 40,
        colorTemp: 80,
        saturation: 25,
        hue: 45 
      },
      { 
        name: '自然光', 
        value: 'natural', 
        color: '#F5F5DC',
        icon: '️',
        description: '舒适明亮',
        brightness: 85,
        colorTemp: 55,
        saturation: 15,
        hue: 60 
      }
    ],
    currentReadingScene: 'eyecare',
    modes: [
      { name: '阅读', value: 'reading', icon: '📚', scenes: [
        { name: '护眼模式', value: 'eyecare', color: '#CCE8CF', brightness: 60 },
        { name: '纸张模式', value: 'paper', color: '#FFF5E1', brightness: 75 },
        { name: '夜间模式', value: 'night', color: '#FFE4B5', brightness: 40 },
        { name: '自然光', value: 'natural', color: '#F5F5DC', brightness: 85 }
      ]},
      { 
        name: '照明', 
        value: 'normal', 
        icon: '💡',
        scenes: [
          { 
            name: '五星红旗',
            value: 'flag',
            icon: '🇨🇳',
            description: '国旗照明',
            color: '#DE2910',
            isFlag: true
          },
          { 
            name: '强白光',
            value: 'strong_white',
            icon: '⚡',
            description: '最大亮度',
            color: '#FFFFFF'
          },
          { 
            name: '强绿光', 
            value: 'strong_green', 
            icon: '🟢',
            description: '绿色照明',
            color: '#00FF00'
          },
          { 
            name: '强红光', 
            value: 'strong_red', 
            icon: '🔴',
            description: '红色照明',
            color: '#FF0000'
          },
          { 
            name: '自定义', 
            value: 'custom_color', 
            icon: '🎨',
            description: '自选颜色',
            color: '#FFFFFF'
          }
        ]
      },
      { 
        name: '氛围', 
        value: 'ambient', 
        icon: '🌟',
        scenes: [
          { 
            name: '生日派对',
            value: 'birthday',
            icon: '🎂',
            description: '温馨庆生',
            color: '#FF69B4',
            videoUrl: '/assets/videos/birthday.mp4',
            textEffect: {
              color: '#FF69B4',
              animation: 'bounce',
              shadow: '0 0 10rpx rgba(255, 105, 180, 0.8)'
            }
          },
          { 
            name: '演唱会',
            value: 'concert',
            icon: '🎤',
            description: '舞台灯光',
            color: '#9370DB',
            videoUrl: '/assets/videos/concert.mp4',
            textEffect: {
              color: '#9370DB',
              animation: 'flash',
              shadow: '0 0 15rpx rgba(147, 112, 219, 0.9)'
            }
          },
          { 
            name: '浪漫表白',
            value: 'dinner',
            icon: '💝',
            description: '甜蜜告白',
            color: '#FF1493',
            videoUrl: '/assets/videos/dinner.mp4',
            textEffect: {
              color: '#FF1493',
              animation: 'heartbeat',
              shadow: '0 0 12rpx rgba(255, 20, 147, 0.8)'
            }
          },
          { 
            name: '运动赛事',
            value: 'movie',
            icon: '⚽️',
            description: '激情竞技',
            color: '#1E90FF',
            videoUrl: '/assets/videos/movie.mp4',
            textEffect: {
              color: '#1E90FF',
              animation: 'shake',
              shadow: '0 0 10rpx rgba(30, 144, 255, 0.8)'
            }
          },
          { 
            name: '派对狂欢',
            value: 'party',
            icon: '🎉',
            description: '缤纷狂欢',
            color: '#FF1493',
            videoUrl: '/assets/videos/party.mp4',
            textEffect: {
              color: '#FF1493',
              animation: 'rotate',
              shadow: '0 0 15rpx rgba(255, 20, 147, 0.9)'
            }
          },
          { 
            name: '节日氛围',
            value: 'relax',
            icon: '🎄',
            description: '欢度佳节',
            color: '#FF4500',
            videoUrl: '/assets/videos/relax.mp4',
            textEffect: {
              color: '#FF4500',
              animation: 'sparkle',
              shadow: '0 0 12rpx rgba(255, 69, 0, 0.8)'
            }
          }
        ]
      },
      { 
        name: '应急', 
        value: 'emergency', 
        icon: '🚨', 
        scenes: [
          {
            name: '彩虹灯',
            value: 'sos',
            icon: '🌈',
            description: '七彩变换',
            color: '#FF0000',
            pattern: 'sos'
          },
          {
            name: '报警灯',
            value: 'alarm',
            icon: '🚨',
            description: '红蓝警灯',
            color: '#0000FF',
            pattern: 'alarm'
          },
          {
            name: '救护车灯',
            value: 'warning',
            icon: '🚑',
            description: '救车警示',
            color: '#0000FF',
            pattern: 'warning'
          },
          {
            name: '紧急停止',
            value: 'stop',
            icon: '🛑',
            description: '红色闪烁',
            color: '#FF0000',
            pattern: 'stop'
          },
          {
            name: '疏散指示',
            value: 'evacuation',
            icon: '🚪',
            description: '绿色箭头',
            color: '#00FF00',
            pattern: 'evacuation'
          },
          {
            name: '救援警示',
            value: 'rescue',
            icon: '🚑',
            description: '黄色警示',
            color: '#FFD700',
            pattern: 'rescue'
          }
        ] 
      },
    ],
    isFullscreen: false,
    currentLightScene: 'strong',
    customColor: '#FFFFFF',
    colorOptions: [
      { name: '暖白', value: '#FFE4C4' },
      { name: '冷白', value: '#F0F8FF' },
      { name: '粉红', value: '#FFC0CB' },
      { name: '橙色', value: '#FFA500' },
      { name: '黄色', value: '#FFFF00' },
      { name: '青色', value: '#00FFFF' },
      { name: '紫色', value: '#800080' },
      { name: '金色', value: '#FFD700' }
    ],
    selectedCustomColor: null,
    lightEffects: [
      { 
        name: '星光点点',
        value: 'starlight',
        icon: '✨',
        description: '浪漫星空',
        config: {
          starCount: 100,
          colors: ['#FFF', '#FFD700', '#87CEEB']
        }
      },
      { 
        name: '心跳律动',
        value: 'heartbeat',
        icon: '💗',
        description: '浪漫心动',
        config: {
          color: '#FF69B4',
          beatInterval: 1000
        }
      },
      { 
        name: '涟���扩散',
        value: 'ripple',
        icon: '🌊',
        description: '水波荡漾',
        config: {
          color: '#00BFFF',
          rippleCount: 3
        }
      },
      { 
        name: '光束旋转',
        value: 'lightbeam',
        icon: '💫',
        description: '炫彩光束',
        config: {
          beamCount: 6,
          colors: ['#FF1493', '#FFD700', '#00FA9A', '#00BFFF']
        }
      },
      { 
        name: '烟花绽放',
        value: 'firework',
        icon: '🎆',
        description: '绚丽烟火',
        config: {
          particleCount: 50,
          colors: ['#FF69B4', '#87CEEB', '#98FB98', '#FFD700']
        }
      },
      { 
        name: '霓虹律动',
        value: 'neon',
        icon: '🌈',
        description: '炫彩霓虹',
        config: {
          colors: ['#FF1493', '#4169E1', '#00FF00', '#FFD700'],
          pulseSpeed: 1500
        }
      }
    ],
    currentEffect: '',
    isVideoPlaying: false,
    lastReadingSettings: null,  // 用于保存读模式的参数
    effectParams: {
      brightness: 100,
      hue: 0,
      saturation: 100
    },
    currentVideo: '',
    ambientColors: [
      { 
        name: '霓虹紫', 
        value: 'neon_purple', 
        mainColor: '#FF00FF',
        accentColor: '#00FFFF',
        description: '赛博朋克'
      },
      { 
        name: '极光绿', 
        value: 'aurora_green', 
        mainColor: '#39FF14',
        accentColor: '#00FF80',
        description: '梦幻极光'
      },
      { 
        name: '星空蓝', 
        value: 'starry_blue', 
        mainColor: '#4169E1',
        accentColor: '#87CEEB',
        description: '深邃星空'
      },
      { 
        name: '日落橙', 
        value: 'sunset_orange', 
        mainColor: '#FF4500',
        accentColor: '#FFD700',
        description: '温暖夕阳'
      },
      { 
        name: '玫瑰金', 
        value: 'rose_gold', 
        mainColor: '#FFB6C1',
        accentColor: '#FFA07A',
        description: '浪漫典雅'
      },
      { 
        name: '海洋蓝', 
        value: 'ocean_blue', 
        mainColor: '#00CED1',
        accentColor: '#20B2AA',
        description: '深海之谜'
      },
      { 
        name: '火焰红', 
        value: 'flame_red', 
        mainColor: '#FF4444',
        accentColor: '#FF8C00',
        description: '热情似火'
      },
      { 
        name: '薰衣草', 
        value: 'lavender', 
        mainColor: '#E6E6FA',
        accentColor: '#9370DB',
        description: '优雅梦幻'
      },
      { 
        name: '翡翠绿', 
        value: 'emerald', 
        mainColor: '#50C878',
        accentColor: '#3CB371',
        description: '自然新'
      },
      { 
        name: '金属银', 
        value: 'metallic', 
        mainColor: '#C0C0C0',
        accentColor: '#A9A9A9',
        description: '现代科技'
      },
      { 
        name: '糖果粉', 
        value: 'candy_pink', 
        mainColor: '#FF69B4',
        accentColor: '#FFB6C1',
        description: '甜美可爱'
      },
      { 
        name: '宝石蓝', 
        value: 'sapphire', 
        mainColor: '#082567',
        accentColor: '#4169E1',
        description: '高贵典雅'
      }
    ],
    selectedAmbientColor: null,
    fontSizes: [
      { 
        name: '小号', 
        value: 'small', 
        size: '80rpx',
        icon: '🔤',
        description: '小巧精致'
      },
      { 
        name: '中号', 
        value: 'medium', 
        size: '120rpx',
        icon: '📝',
        description: '标准大小'
      },
      { 
        name: '大号', 
        value: 'large', 
        size: '160rpx',
        icon: '📢',
        description: '醒目清晰'
      },
      { 
        name: '超大', 
        value: 'xlarge', 
        size: '200rpx',
        icon: '🔎',
        description: '震撼视觉'
      }
    ],
    selectedFontSize: 'medium',  // 默认中号字体
    scrollDirections: [
      { name: '向左滚动', value: 'left', icon: '️' },
      { name: '居中静止', value: 'center', icon: '' },
      { name: '向右滚动', value: 'right', icon: '➡️' }
    ],
    selectedScrollDirection: 'center',
    fontStyles: [
      { 
        name: '默认',
        value: 'default',
        icon: '📝',
        font: 'system-ui',
        description: '系统默认'
      },
      { 
        name: '宋体',
        value: 'songti',
        icon: '🖋',
        font: 'SimSun',
        description: '优雅典雅'
      },
      { 
        name: '黑体',
        value: 'heiti',
        icon: '✒️',
        font: 'SimHei',
        description: '醒目有力'
      },
      { 
        name: '楷体',
        value: 'kaiti',
        icon: '🖊',
        font: 'KaiTi',
        description: '流畅自然'
      },
      {
        name: '圆体',
        value: 'yuanti',
        icon: '🖌',
        font: 'YouYuan',
        description: '活泼可爱'
      },
      {
        name: '仿宋',
        value: 'fangsong',
        icon: '✍️',
        font: 'FangSong',
        description: '庄重大方'
      }
    ],
    selectedFontStyle: 'default',  // 当前选中的字体样式
    customText: '',  // 用户输入的文字
    selectedText: '',  // 当前选中的文字
    currentEmergencyScene: '',
    isEmergencyActive: false,
    emergencyTimer: null,
    sosSignalOn: false,  // 控制 SOS 信号的开关状态
    alarmState: 0,  // 用于 wxml 中控制显示效果
    showAlarmEffect: false,  // 用于在 wxml 中控制显示效果
    warningState: 0,  // 用于在 wxml 中控制显示效果
    showWarningEffect: false,  // 用于在 wxml 中控制显示效果
    evacuationState: true,  // 用于在 wxml 中控制显示效果
    showEvacuationEffect: false,  // 用于在 wxml 中控制显示效果
    emergencyEffects: {
      sos: {
        active: false,
        timer: null,
        signalOn: false
      },
      alarm: {
        active: false,
        timer: null,
        state: 0
      },
      warning: {
        active: false,
        timer: null,
        state: 0
      },
      stop: {
        active: false,
        timer: null
      },
      evacuation: {
        active: false,
        timer: null,
        state: true
      },
      rescue: {
        active: false,
        timer: null
      }
    },
    isSOSActive: false, // 是否正在发送 SOS 信号
    sosTimer: null, // SOS 定时器
  },

  onLoad() {
    // 获取护眼模的默认参数
    const eyecareScene = this.data.readingScenes.find(s => s.value === 'eyecare');
    
    // 设置默认的阅读模式参数
    this.setData({
      currentMode: 'reading',
      currentReadingScene: 'eyecare',
      brightness: eyecareScene.brightness,
      colorTemp: eyecareScene.colorTemp,
      saturation: eyecareScene.saturation,
      hue: eyecareScene.hue
    });
  },

  // 切换阅读场景
  switchReadingScene(e) {
    const sceneValue = e.currentTarget.dataset.scene;
    const scene = this.data.readingScenes.find(s => s.value === sceneValue);
    
    if (this.data.currentReadingScene !== sceneValue) {
      this.setData({ 
        currentReadingScene: sceneValue,
        brightness: scene.brightness,
        colorTemp: scene.colorTemp,
        saturation: scene.saturation,
        hue: scene.hue
      });
    }
  },

  // 调节亮度
  adjustBrightness(e) {
    const brightness = e.detail.value;
    this.setData({ brightness });
  },

  // 调节色温
  adjustColorTemp(e) {
    const colorTemp = e.detail.value;
    this.setData({ colorTemp });
  },

  // 调节饱和度
  adjustSaturation(e) {
    const saturation = e.detail.value;
    this.setData({ saturation });
  },

  // 调节色
  adjustHue(e) {
    const hue = e.detail.value;
    this.setData({ hue });
  },

  // 更新灯光设置
  updateLightSettings() {
    console.log('更新灯光设:', {
      brightness: this.data.brightness,
      colorTemp: this.data.colorTemp,
      saturation: this.data.saturation,
      hue: this.data.hue
    });
  },

  // 设置光颜色
  setLightColor(color) {
    console.log('设置灯光颜色:', color);
  },

  // 修改全屏切换方法
  toggleFullscreen() {
    const isFullscreen = !this.data.isFullscreen;
    
    this.setData({ isFullscreen });
    
    if (isFullscreen) {
      // 进入全屏时隐藏导航栏
      wx.hideNavigationBarLoading();
      wx.setNavigationBarColor({
        frontColor: '#000000',
        backgroundColor: '#ffffff',
        animation: {
          duration: 200,
          timingFunc: 'easeIn'
        }
      });
    } else {
      // 退出全屏时显示导航栏
      wx.hideNavigationBarLoading();
      wx.setNavigationBarColor({
        frontColor: '#000000',
        backgroundColor: '#ffffff',
        animation: {
          duration: 200,
          timingFunc: 'easeOut'
        }
      });
    }
  },

  // 修改点击背景退出全屏的方法
  tapBackground() {
    if (this.data.isFullscreen) {
      // 停止所有可能的效果
      if (this.data.currentEmergencyScene) {
        // 清除应急模式的定时器和效果
        if (this.data.emergencyTimer) {
          clearTimeout(this.data.emergencyTimer);
          clearInterval(this.data.emergencyTimer);
        }
        
        this.setData({
          currentEmergencyScene: '',
          showRainbowEffect: false,
          showAlarmEffect: false,
          showWarningEffect: false,
          showEvacuationEffect: false,
          showConcertEffect: false,
          emergencyTimer: null,
          isEmergencyActive: false
        });
      }

      // 停止视频播放
      if (this.data.isVideoPlaying) {
        this.setData({
          currentEffect: '',
          isVideoPlaying: false,
          currentVideo: ''
        });
      }

      // 重置照明模式的状态
      if (this.data.currentLightScene) {
        this.setData({
          currentLightScene: '',
          backgroundColor: null,
          showFlag: false  // 关闭国旗显示
        });
      }

      // 退出全屏
      this.setData({ 
        isFullscreen: false 
      });
      
      // 恢复导航栏
      wx.hideNavigationBarLoading();
      wx.setNavigationBarColor({
        frontColor: '#000000',
        backgroundColor: '#ffffff',
        animation: {
          duration: 200,
          timingFunc: 'easeOut'
        }
      });
    }
  },

  // 修改 switchMode 函数
  switchMode(e) {
    const mode = e.currentTarget.dataset.mode;
    console.log('切换到模式:', mode);
    this.setData({ currentMode: mode });
    
    // 如果切换到应急模式，停止其他模式的效果
    if (mode === 'emergency') {
      if (this.data.isVideoPlaying) {
        this.stopLightEffect();
      }
      if (this.data.lastReadingSettings) {
        this.setData({
          lastReadingSettings: {
            brightness: this.data.brightness,
            colorTemp: this.data.colorTemp,
            saturation: this.data.saturation,
            hue: this.data.hue
          }
        });
      }
    }
  },

  // 添加切换照明场景的方法
  switchLightScene(e) {
    const sceneValue = e.currentTarget.dataset.scene;
    const scene = this.data.modes[1].scenes.find(s => s.value === sceneValue);
    
    if (sceneValue === 'custom_color') {
      this.chooseCustomColor();
      return;
    }
    
    this.setData({ 
      currentLightScene: sceneValue,
      brightness: 100,
      isFullscreen: true,
      backgroundColor: scene.color,
      showFlag: scene.isFlag
    });

    // 隐藏导航栏
    wx.hideNavigationBarLoading();
    wx.setNavigationBarColor({
      frontColor: '#000000',
      backgroundColor: '#ffffff',
      animation: {
        duration: 200,
        timingFunc: 'easeIn'
      }
    });
  },

  // 修改 chooseCustomColor 方
  chooseCustomColor() {
    const colors = [
      { name: '暖', value: '#FFE4C4' },
      { name: '冷白', value: '#F0F8FF' },
      { name: '粉红', value: '#FFC0CB' },
      { name: '橙色', value: '#FFA500' },
      { name: '黄色', value: '#FFFF00' },
      { name: '青色', value: '#00FFFF' },
      { name: '紫色', value: '#800080' },
      { name: '金色', value: '#FFD700' }
    ];

    wx.showActionSheet({
      itemList: colors.map(c => c.name),
      success: (res) => {
        const selectedColor = colors[res.tapIndex].value;
        
        // 显示确认对话框
        wx.showModal({
          title: '确认选择',
          content: '是否用该颜色？',
          success: (res) => {
            if (res.confirm) {
              this.setData({
                customColor: selectedColor,
                'modes[1].scenes[4].color': selectedColor,
                backgroundColor: selectedColor,
                isFullscreen: true // 确认后直接进入全屏
              });

              // 隐藏导航栏
              wx.hideNavigationBarLoading();
              wx.setNavigationBarColor({
                frontColor: '#000000',
                backgroundColor: '#ffffff',
                animation: {
                  duration: 200,
                  timingFunc: 'easeIn'
                }
              });
            }
          }
        });
      }
    });
  },

  // 添加选择自定义颜色的方法
  selectCustomColor(e) {
    const color = e.currentTarget.dataset.color;
    this.setData({ selectedCustomColor: color });
  },

  // 添加确认选择法
  confirmCustomColor() {
    if (!this.data.selectedCustomColor) return;
    
    this.setData({
      customColor: this.data.selectedCustomColor,
      'modes[1].scenes[4].color': this.data.selectedCustomColor,
      backgroundColor: this.data.selectedCustomColor,
      isFullscreen: true
    });

    // 隐藏导航栏
    wx.hideNavigationBarLoading();
    wx.setNavigationBarColor({
      frontColor: '#000000',
      backgroundColor: '#ffffff',
      animation: {
        duration: 200,
        timingFunc: 'easeIn'
      }
    });
  },

  // 修改切换灯光特效的方法
  switchLightEffect(e) {
    try {
      const effectValue = e.currentTarget.dataset.effect;
      const effect = this.data.lightEffects.find(ef => ef.value === effectValue);
      
      if (!effect) {
        throw new Error('Invalid effect value');
      }
      
      if (this.data.currentEffect === effectValue && this.data.isVideoPlaying) {
        this.stopLightEffect();
        return;
      }

      this.setData({ 
        currentEffect: effectValue,
        isVideoPlaying: true,
        isFullscreen: true,
        currentVideo: effect.videoUrl
      });
    } catch (error) {
      console.error('Error in switchLightEffect:', error);
      wx.showToast({
        title: '切换果失败',
        icon: 'none'
      });
    }
  },

  // 修改停止灯光特效的方法
  stopLightEffect() {
    this.setData({
      currentEffect: '',
      isVideoPlaying: false,
      isFullscreen: false,
      currentVideo: ''
    });

    // 显示导航栏
    wx.showNavigationBar();
    wx.setNavigationBarColor({
      frontColor: '#000000',
      backgroundColor: '#ffffff',
      animation: {
        duration: 200,
        timingFunc: 'easeOut'
      }
    });
  },

  // 修改 switchAmbientScene 方法
  switchAmbientScene(e) {
    const sceneValue = e.currentTarget.dataset.scene;
    const scene = this.data.modes[2].scenes.find(s => s.value === sceneValue);
    
    // 如果点击当前场景，则取消选择
    if (this.data.currentAmbientScene === sceneValue) {
      this.setData({ 
        currentAmbientScene: ''
      });
      wx.showToast({
        title: '已取消选择',
        icon: 'none'
      });
      return;
    }
    
    // 选择新场景
    this.setData({ 
      currentAmbientScene: sceneValue
    });

    // 显示选中提示
    wx.showToast({
      title: `已选择${scene.name}效果`,
      icon: 'none'
    });
  },

  // 添加停止氛围效果的方法
  stopAmbientEffect() {
    this.setData({
      currentAmbientScene: '',
      isFullscreen: false,
      showConcertEffect: false
    });
  },

  // 添加字号选择法
  selectFontSize(e) {
    const size = e.currentTarget.dataset.size;
    this.setData({ 
      selectedFontSize: size,
      // 选择字号时取消其他相关设置，避免冲突
      currentAmbientScene: ''
    });

    const selectedSize = this.data.fontSizes.find(s => s.value === size);
    wx.showToast({
      title: `已选择${selectedSize.name}字体`,
      icon: 'none'
    });
  },

  // 添加滚动方向选择方法
  selectScrollDirection(e) {
    const direction = e.currentTarget.dataset.direction;
    this.setData({ selectedScrollDirection: direction });
  },

  // 添加字体样式选择方法
  selectFontStyle(e) {
    const fontStyle = e.currentTarget.dataset.font;
    this.setData({ 
      selectedFontStyle: fontStyle,
      // 选择字体时取消其他相关设置，避免冲突
      currentAmbientScene: ''
    });

    const selectedFont = this.data.fontStyles.find(f => f.value === fontStyle);
    wx.showToast({
      title: `已选择${selectedFont.name}字体`,
      icon: 'none'
    });
  },

  // 添加自定义文字输入方法
  inputCustomText() {
    wx.showModal({
      title: '输入文字',
      placeholderText: '请输入要显示的文字',
      editable: true,
      content: this.data.customText,
      success: (res) => {
        if (res.confirm && res.content) {
          this.setData({
            customText: res.content,
            selectedText: res.content
          });
        }
      }
    });
  },

  // 添加预设文字选择方法
  selectPresetText(e) {
    const text = e.currentTarget.dataset.text;
    this.setData({ selectedText: text });
  },

  // 修改确认文字的方法，添加字体样式设置
  confirmCustomText() {
    if (!this.data.customText) {
      wx.showToast({
        title: '请先输入文字',
        icon: 'none'
      });
      return;
    }

    // 收集所有设置参数
    const params = {
      text: this.data.customText,
      // 氛围场景设置
      scene: this.data.currentAmbientScene ? 
        this.data.modes[2].scenes.find(s => s.value === this.data.currentAmbientScene) : null,
      // 自定义配色设置
      color: this.data.selectedAmbientColor ? {
        mainColor: this.data.selectedAmbientColor.mainColor,
        accentColor: this.data.selectedAmbientColor.accentColor,
        description: this.data.selectedAmbientColor.description
      } : null,
      // 字号设置
      fontSize: this.data.selectedFontSize ? 
        this.data.fontSizes.find(s => s.value === this.data.selectedFontSize)?.size : '32rpx',
      // 滚动方向
      scrollDirection: this.data.selectedScrollDirection || 'center',
      // 字体样式
      fontStyle: this.data.selectedFontStyle ? 
        this.data.fontStyles.find(f => f.value === this.data.selectedFontStyle) : {
          font: 'system-ui',
          description: '系统默认'
        }
    };

    console.log('传递的参数:', params);

    // 跳转到滚动文字页面，传递所有参数
    wx.navigateTo({
      url: `/pages/scrollText/scrollText?params=${encodeURIComponent(JSON.stringify(params))}`
    });
  },

  // 修改应急场景切换方法
  switchEmergencyScene(e) {
    const sceneValue = e.currentTarget.dataset.scene;
    const scene = this.data.modes[3].scenes.find(s => s.value === sceneValue);
    
    // 如果已经在显示这个效果，则停止并返回
    if (this.data.currentEmergencyScene === sceneValue) {
      this.stopSpecificEffect(sceneValue);
      return;
    }
    
    // 如果有其他效果运行，先停止它
    if (this.data.currentEmergencyScene) {
      this.stopSpecificEffect(this.data.currentEmergencyScene);
    }
    
    // 启动新效果
    this.setData({ 
      isFullscreen: true,
      currentEmergencyScene: sceneValue,
      // 重置所有效果的显示状态
      showSOSEffect: false,
      showAlarmEffect: false,
      showWarningEffect: false,
      showEvacuationEffect: false,
      // 设置当前效果的显示状态
      [`show${sceneValue.charAt(0).toUpperCase() + sceneValue.slice(1)}Effect`]: true
    });

    // 根据场景类型启动相应效果
    switch(sceneValue) {
      case 'sos':
        this.startSOSEffect();
        break;
      case 'alarm':
        this.startAlarmEffect();
        break;
      case 'warning':
        this.startWarningEffect();
        break;
      case 'stop':
        this.startStopEffect();
        break;
      case 'evacuation':
        this.startEvacuationEffect();
        break;
      case 'rescue':
        this.startRescueEffect();
        break;
      case 'concert':
        this.startConcertEffect();
        break;
    }
  },

  // 修改停止特定效果的方
  stopSpecificEffect(effectType) {
    // 清除定时器
    if (this.data.emergencyTimer) {
      clearTimeout(this.data.emergencyTimer);
      clearInterval(this.data.emergencyTimer);
    }
    
    // 关闭手电筒
    wx.torchOff();
    
    // 重置状态
    this.setData({
      isFullscreen: false,
      currentEmergencyScene: '',
      backgroundColor: null,
      [`show${effectType.charAt(0).toUpperCase() + effectType.slice(1)}Effect`]: false,
      emergencyTimer: null
    });
  },

  // 修改彩虹灯效果函数
  startSOSEffect() {
    const colors = [
      '#FF0000', // 红
      '#FF7F00', // 橙
      '#FFFF00', // 黄
      '#00FF00', // 绿
      '#0000FF', // 蓝
      '#4B0082', // 靛
      '#8B00FF', // 紫
      '#FF0000'  // 再加一个红色实现无缝循环
    ];
    
    this.setData({
      isEmergencyActive: true,
      isFullscreen: true,
      showRainbowEffect: true,
      rainbowColors: colors,
      backgroundColor: 'transparent'
    });
  },

  // 修改报警灯效果函数
  startAlarmEffect() {
    const flashInterval = 300; // 闪烁间隔（毫秒）
    let state = 0; // 0: 上红下黑, 1: 上黑下蓝
    
    this.setData({
      isEmergencyActive: true,
      isFullscreen: true,
      showAlarmEffect: true
    });
    
    const timer = setInterval(() => {
      if (!this.data.isEmergencyActive) {
        clearInterval(timer);
        return;
      }

      switch(state) {
        case 0: // 上红下黑
          this.setData({ 
            alarmState: state,
            backgroundColor: null
          });
          break;
        case 1: // 上黑下蓝
          this.setData({ 
            alarmState: state,
            backgroundColor: null
          });
          break;
      }
      
      state = 1 - state; // 切换状态
    }, flashInterval);

    this.setData({ 
      emergencyTimer: timer
    });
  },

  // 修改紧急停止效果函数
  startStopEffect() {
    const flashInterval = 500; // 闪烁间隔（毫秒）
    let isOn = true;
    
    this.setData({
      isEmergencyActive: true,
      isFullscreen: true
    });
    
    const timer = setInterval(() => {
      if (!this.data.isEmergencyActive) {
        clearInterval(timer);
        return;
      }

      this.setData({ 
        backgroundColor: isOn ? '#FF0000' : '#000000'
      });
      
      isOn = !isOn;
    }, flashInterval);

    this.setData({ 
      emergencyTimer: timer
    });
  },

  // 修改救护车灯效果函数
  startWarningEffect() {
    const flashInterval = 300; // 闪烁间隔（毫秒）
    let state = 0; // 0: 上蓝下黑, 1: 上黑下白
    
    this.setData({
      isEmergencyActive: true,
      isFullscreen: true,
      showWarningEffect: true
    });
    
    const timer = setInterval(() => {
      if (!this.data.isEmergencyActive) {
        clearInterval(timer);
        return;
      }

      switch(state) {
        case 0: // 上蓝下黑
          this.setData({ 
            warningState: state,
            backgroundColor: null
          });
          break;
        case 1: // 上黑下白
          this.setData({ 
            warningState: state,
            backgroundColor: null
          });
          break;
      }
      
      state = 1 - state; // 切换状态
    }, flashInterval);

    this.setData({ 
      emergencyTimer: timer
    });
  },

  // 修改疏散指示效果函数
  startEvacuationEffect() {
    const fadeInterval = 1000; // 渐变间隔（毫秒）
    let isBright = true;
    
    this.setData({
      isEmergencyActive: true,
      isFullscreen: true,
      showEvacuationEffect: true
    });
    
    const timer = setInterval(() => {
      if (!this.data.isEmergencyActive) {
        clearInterval(timer);
        return;
      }

      this.setData({ 
        evacuationState: isBright,
        backgroundColor: '#001800' // 设置深绿色背景
      });
      
      isBright = !isBright;
    }, fadeInterval);

    this.setData({ 
      emergencyTimer: timer
    });
  },

  // 修改救援警示灯效果函数
  startRescueEffect() {
    const flashInterval = 500; // 闪烁间隔（毫秒）
    let isOn = true;
    
    this.setData({
      isEmergencyActive: true,
      isFullscreen: true
    });
    
    const timer = setInterval(() => {
      if (!this.data.isEmergencyActive) {
        clearInterval(timer);
        return;
      }

      this.setData({ 
        backgroundColor: isOn ? '#FFD700' : '#000000' // 使用金黄色
      });
      
      isOn = !isOn;
    }, flashInterval);

    this.setData({ 
      emergencyTimer: timer
    });
  },

  // 页面隐藏时停止闪烁
  onHide() {
    this.stopMorseEffect();
  },

  // 页面卸载时停止闪烁
  onUnload() {
    this.stopMorseEffect();
  },

  // Add cleanup method for better memory management
  onUnload() {
    // Clear all timers and intervals
    if (this.data.emergencyTimer) {
        clearInterval(this.data.emergencyTimer);
        clearTimeout(this.data.emergencyTimer);
    }
    
    // Stop all emergency effects
    Object.keys(this.data.emergencyEffects).forEach(effect => {
      if (this.data.emergencyEffects[effect].timer) {
        clearInterval(this.data.emergencyEffects[effect].timer);
        clearTimeout(this.data.emergencyEffects[effect].timer);
      }
    });
    
    // Clear video resources
    if (this.data.isVideoPlaying) {
        this.stopLightEffect();
    }
    
    // Reset all states
    this.setData({
      currentEffect: '',
      currentEmergencyScene: '',
      isVideoPlaying: false,
      isEmergencyActive: false,
      currentVideo: '',
      emergencyTimer: null,
      emergencyEffects: {
        sos: { active: false, timer: null },
        alarm: { active: false, timer: null },
        warning: { active: false, timer: null },
        stop: { active: false, timer: null },
        evacuation: { active: false, timer: null },
        rescue: { active: false, timer: null }
      }
    });
  },

  // Modify emergency effect methods to use a single timer management system
  startEmergencyEffect(type, config) {
    // Stop any existing effects first
    this.stopAllEmergencyEffects();
    
    const timer = setInterval(() => {
      if (!this.data.isEmergencyActive) {
        clearInterval(timer);
        return;
      }
      
      switch(type) {
        case 'sos':
          this.updateSOSEffect(config);
          break;
        case 'alarm':
          this.updateAlarmEffect(config);
          break;
        // ... other effects
      }
    }, config.interval || 500);
    
    this.setData({
      [`emergencyEffects.${type}`]: {
        active: true,
        timer: timer
      },
      isEmergencyActive: true,
      isFullscreen: true
    });
  },

  stopAllEmergencyEffects() {
    Object.keys(this.data.emergencyEffects).forEach(effect => {
      if (this.data.emergencyEffects[effect].timer) {
        clearInterval(this.data.emergencyEffects[effect].timer);
      }
    });
    
    this.setData({
      isEmergencyActive: false,
      currentEmergencyScene: '',
      emergencyEffects: {
        sos: { active: false, timer: null },
        alarm: { active: false, timer: null },
        warning: { active: false, timer: null },
        stop: { active: false, timer: null },
        evacuation: { active: false, timer: null },
        rescue: { active: false, timer: null }
      }
    });
  },

  // Add method to validate and reset settings
  resetToDefaults() {
    this.setData({
      brightness: this.data.defaultSettings.brightness,
      colorTemp: this.data.defaultSettings.colorTemp,
      saturation: this.data.defaultSettings.saturation,
      hue: this.data.defaultSettings.hue
    });
  },

  // SOS 手电筒功能
  async startSOSFlashlight() {
    if (this.data.isSOSActive) {
      this.stopSOSFlashlight();
      return;
    }

    try {
      // 请求相机权限
      await wx.authorize({ scope: 'scope.camera' });
      
      this.setData({ isSOSActive: true });
      
      // SOS 信号模式: ... --- ...
      const sosPattern = [
        200, 200, 200, // 三个点 (.)
        600, // 间隔
        600, 600, 600, // 三个划 (-)
        600, // 间隔
        200, 200, 200  // 三个点 (.)
      ];
      
      const runSOS = async () => {
        if (!this.data.isSOSActive) return;
        
        for (const duration of sosPattern) {
          if (!this.data.isSOSActive) break;
          
          try {
            await wx.setTorchSwitch({ torch: true });
            await this.delay(duration);
            await wx.setTorchSwitch({ torch: false });
            await this.delay(200); // 每个信号之间的间隔
          } catch (error) {
            console.error('闪光灯控制失败:', error);
            this.stopSOSFlashlight();
            wx.showToast({
              title: '手电筒控制失败',
              icon: 'none'
            });
            break;
          }
        }
        
        // 完整的 SOS 信号之间的间隔
        if (this.data.isSOSActive) {
          await this.delay(1000);
          runSOS(); // 循环发送 SOS 信号
        }
      };

      runSOS();
      
    } catch (error) {
      wx.showToast({
        title: '需要相机权限来控制闪光灯',
        icon: 'none'
      });
    }
  },

  // 停止 SOS 信号
  stopSOSFlashlight() {
    this.setData({ isSOSActive: false });
    wx.setTorchSwitch({ torch: false }).catch(error => {
      console.error('关闭闪光灯失败:', error);
    });
  },

  // 延时函数
  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  },

  // 页面隐藏时停止 SOS
  onHide() {
    this.stopSOSFlashlight();
  },

  // 页面卸载时停止 SOS
  onUnload() {
    this.stopSOSFlashlight();
  }
})
