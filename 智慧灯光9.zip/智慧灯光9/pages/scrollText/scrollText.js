Page({
  data: {
    text: '',
    scene: null,
    color: null,
    fontSize: '32rpx',
    scrollDirection: 'center',
    fontStyle: null,
    effectElements: [],
    effectTimer: null,
    animationDuration: 20
  },

  onLoad(options) {
    try {
      const params = JSON.parse(decodeURIComponent(options.params));
      console.log('接收到的参数:', params);
      
      // 根据文字长度调整动画时间
      const textLength = (params.text || '').length;
      const duration = Math.max(20, Math.min(textLength * 0.5, 60));
      
      this.setData({
        text: params.text || '',
        scene: params.scene || null,
        color: params.color || null,
        fontSize: params.fontSize || '32rpx',
        scrollDirection: params.scrollDirection || 'center',
        fontStyle: params.fontStyle || {
          font: 'system-ui',
          description: '系统默认'
        },
        animationDuration: duration
      });

      // 如果有场景特效，启动特效
      if (params.scene && params.scene.textEffect) {
        this.startSceneEffect(params.scene);
      }
    } catch (error) {
      console.error('参数解析错误:', error);
      wx.showToast({
        title: '参数错误',
        icon: 'none'
      });
    }
  },

  startSceneEffect(scene) {
    // 根据场景类型生成对应的特效元素
    let elements = [];
    switch(scene.value) {
      case 'birthday':
        elements = ['🎂', '🎈', '🎉', '🎊', '🎁'];
        break;
      case 'concert':
        elements = ['🎵', '🎶', '🎸', '🎹', '🎺'];
        break;
      case 'dinner':
        elements = ['💝', '💖', '💗', '💓', '🌹'];
        break;
      case 'movie':
        elements = ['⚽️', '🏀', '🏈', '⚾️', '🎯'];
        break;
      case 'party':
        elements = ['🎉', '🎊', '✨', '🎈', '🎆'];
        break;
      case 'relax':
        elements = ['🎄', '🎁', '❄️', '⭐', '🔔'];
        break;
    }

    // 开始生成特效
    const timer = setInterval(() => {
      const newElements = [];
      const count = Math.floor(Math.random() * 3) + 2;
      
      for (let i = 0; i < count; i++) {
        const element = elements[Math.floor(Math.random() * elements.length)];
        const left = Math.random() * 100;
        const delay = Math.random() * 2;
        const duration = 3 + Math.random() * 2;
        const scale = 0.5 + Math.random() * 1;
        
        newElements.push({
          content: element,
          style: `left: ${left}vw; animation-delay: ${delay}s; animation-duration: ${duration}s; transform: scale(${scale});`
        });
      }
      
      this.setData({
        effectElements: [...this.data.effectElements, ...newElements].slice(-20)
      });
    }, 500);

    this.setData({ effectTimer: timer });
  },

  // 添加退出方法
  exitPage() {
    // 清理定时器
    if (this.data.effectTimer) {
      clearInterval(this.data.effectTimer);
    }
    // 返回上一页
    wx.navigateBack();
  },

  onUnload() {
    // 清理定时器
    if (this.data.effectTimer) {
      clearInterval(this.data.effectTimer);
    }
  }
}); 