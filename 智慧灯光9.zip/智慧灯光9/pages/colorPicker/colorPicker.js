Page({
  data: {
    red: 255,
    green: 255,
    blue: 255,
    color: '#FFFFFF'
  },

  // 调节红色值
  adjustRed(e) {
    const red = e.detail.value;
    this.updateColor(red, this.data.green, this.data.blue);
  },

  // 调节绿色值
  adjustGreen(e) {
    const green = e.detail.value;
    this.updateColor(this.data.red, green, this.data.blue);
  },

  // 调节蓝色值
  adjustBlue(e) {
    const blue = e.detail.value;
    this.updateColor(this.data.red, this.data.green, blue);
  },

  // 更新颜色
  updateColor(r, g, b) {
    const color = '#' + 
      r.toString(16).padStart(2, '0') + 
      g.toString(16).padStart(2, '0') + 
      b.toString(16).padStart(2, '0');
    
    this.setData({
      red: r,
      green: g,
      blue: b,
      color: color.toUpperCase()
    });
  },

  // 确认选择
  confirmColor() {
    const eventChannel = this.getOpenerEventChannel();
    eventChannel.emit('selectColor', this.data.color);
    wx.navigateBack();
  }
}); 