func setupStrongLightMode() {
    // 现有代码...
    
    // 创建五星红旗的图层
    let flagContainer = CALayer()
    flagContainer.frame = torchView.bounds
    flagContainer.backgroundColor = UIColor(red: 222/255, green: 41/255, blue: 16/255, alpha: 1.0).cgColor // #DE2910
    
    // 创建旗面背景
    let flagBackground = CALayer()
    let width = torchView.bounds.width * 0.9
    let height = width * 2/3  // 3:2 比例
    flagBackground.frame = CGRect(
        x: (torchView.bounds.width - width)/2,
        y: (torchView.bounds.height - height)/2,
        width: width,
        height: height
    )
    flagBackground.backgroundColor = UIColor(red: 222/255, green: 41/255, blue: 16/255, alpha: 1.0).cgColor
    
    // 添加星星图层
    // ... 添加大星和四颗小星的代码
    
    torchView.layer.mask = flagContainer
    
    // 现有代码...
} 